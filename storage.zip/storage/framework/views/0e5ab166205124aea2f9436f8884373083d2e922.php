<?php $__env->startSection('konten2'); ?>
<section id="berita" class="sm:grid sm:grid-cols-2">
    <div class="p-2 prose container mx-auto">
        <h1>Berita 1</h1>
        <img src="<?php echo e(asset('image/10.jpg')); ?>" alt="" class="w-full">
        <p class="line-clamp-6">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloribus explicabo ratione et aspernatur. Mollitia, nostrum! Assumenda, neque? Ratione libero numquam similique aut eos neque aliquid a nobis ex minus ullam fuga laudantium, distinctio cum ipsa? Provident porro animi suscipit voluptas aut earum ducimus dolor cumque molestias officia, amet id aperiam! Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab animi beatae excepturi nisi consequatur rem eum asperiores, officia quis aut ad incidunt aliquam quas modi sunt quam, non, illo obcaecati vero. Eaque numquam quis quos facilis, tenetur, voluptas, aut praesentium dolore consequatur nostrum reprehenderit. Ullam, repellendus eligendi libero nam nobis molestiae et, sint ipsum vitae, nisi explicabo impedit dolore. Illum veritatis et vel sint deleniti soluta necessitatibus libero, in, assumenda perferendis iure, sit magnam quibusdam nihil quaerat nemo adipisci consequuntur nesciunt vitae. Consectetur tempore labore pariatur non neque ut eligendi eius, rerum dolores vitae aspernatur modi voluptatum nostrum. Odit, impedit.
        </p>
    </div>
    <div class="p-2 prose container mx-auto">
        <h1>Berita 2</h1>
        <img src="<?php echo e(asset('image/12.jpg')); ?>" alt="" class="w-full">
        <p class="line-clamp-6">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloribus explicabo ratione et aspernatur. Mollitia, nostrum! Assumenda, neque? Ratione libero numquam similique aut eos neque aliquid a nobis ex minus ullam fuga laudantium, distinctio cum ipsa? Provident porro animi suscipit voluptas aut earum ducimus dolor cumque molestias officia, amet id aperiam! Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab animi beatae excepturi nisi consequatur rem eum asperiores, officia quis aut ad incidunt aliquam quas modi sunt quam, non, illo obcaecati vero. Eaque numquam quis quos facilis, tenetur, voluptas, aut praesentium dolore consequatur nostrum reprehenderit. Ullam, repellendus eligendi libero nam nobis molestiae et, sint ipsum vitae, nisi explicabo impedit dolore. Illum veritatis et vel sint deleniti soluta necessitatibus libero, in, assumenda perferendis iure, sit magnam quibusdam nihil quaerat nemo adipisci consequuntur nesciunt vitae. Consectetur tempore labore pariatur non neque ut eligendi eius, rerum dolores vitae aspernatur modi voluptatum nostrum. Odit, impedit.
        </p>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('webProfil', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmerphpjavascript/Documents/website-portofolio-sekolah/web_portal_test/resources/views/webBerita.blade.php ENDPATH**/ ?>