<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <?php if($message = Session::get('sukses')): ?>
                <div class="alert alert-info container mx-auto" style="max-width: 18rem;">
                    <?php echo e($message); ?>

                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger container mx-auto" style="max-width: 24rem;">
                    <?php echo e($item); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body p-3 text-center">
                    <button type="submit" class="btn btn-primary">
                        <a href="<?php echo e(url('/home/berita')); ?>" class="text-white" style="text-decoration: none;">CRUD Berita</a>
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <a href="<?php echo e(url('/home/profil')); ?>" class="text-white" style="text-decoration: none;">UPDATE Profil</a>
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <a href="<?php echo e(url('/home/beranda')); ?>" class="text-white" style="text-decoration: none;">UPDATE Beranda</a>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmerphpjavascript/Documents/website-portofolio-sekolah/web_portal_test/resources/views/home.blade.php ENDPATH**/ ?>