<?php $__env->startSection('cont'); ?>
<h1 class="text-center text-4xl mb-5">Berita</h1>
<section id="berita" class="sm:grid sm:grid-cols-2">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="p-2 prose container mx-auto">
        <h1><?php echo e($item3->judul); ?></h1>
        <img src="<?php echo e($item3->link_gambar); ?>" alt="" class="w-full">
        <p class="line-clamp-6 hover:line-clamp-none">
            <?php echo e($item3->isi); ?>

        </p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
]<?php $__env->stopSection(); ?>

<?php echo $__env->make('portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmerphpjavascript/Documents/website-portofolio-sekolah/web_portal_test/resources/views/berita.blade.php ENDPATH**/ ?>