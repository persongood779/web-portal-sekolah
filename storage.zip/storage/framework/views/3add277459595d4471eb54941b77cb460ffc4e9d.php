<?php $__env->startSection('konten1'); ?>
<section id="profil" class="my-10">
    <div class="prose prose-h1:mb-0 prose-p:mt-0 block mx-auto text-center prose-sm">
        <h1> Jurusan SMK Al-Azhar </h1>
        <p>Berikut adalah 5 jurusan di smk al-azhar</p>
    </div>
    <section id="jurusan" class="sm:grid sm:grid-cols-2 sm:self-center lg:grid-cols-3 lg:container lg:mx-auto">
        <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
            <h2> AKUNTANSI DAN KEAUANGAN LEMBAGA (AKL) </h2>
            <p> Akuntan adalah salah satu profesi yang paling populer sekaligus paling dibutuhkan dimanapun. Selama ini, akuntan sudah menjadi suatu profesi yang terhormat yang tak kalah pamornya dari profesi semacam ahli hukum, dokter, dan lain-lain. Akuntan adalah orang yang ahli akuntansi. </p>
        </div>

        <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
            <h2> TEKNIK KENDARAAN RINGAN OTOMOTIF (TKRO) </h2>
            <p> Pada Kompetensi Keahlian Teknik Kendaraan Ringan Otomotif akan mempelajari mata pelajaran yang digolongkan dalam 3 muatan yaitu muatan nasional (A), muatan kewilayahan (B) dan muatan peminatan kejuruan (C). </p>
        </div>
        <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
            <h2> REKAYASA PERANGKAT LUNAK (RPL) </h2>
            <p> Rekayasa perangkat lunak (RPL, atau dalam bahasa Inggris: Software Engineering atau SE) adalah satu bidang profesi yang mendalami cara-cara pengembangan software/perangkat lunak termasuk pembuatan, pengembangan perangkat lunak/software dan manajemen kualitas. </p>
        </div>

        <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
            <h2> TEKNIK KOMPUTER DAN JARINGAN (TKJ) </h2>
            <p> Teknik Komputer & Jaringan (TKJ) merupakan salah satu program keahlian SMK yang bergerak di bidang Informasi dan Teknologi. Siswa jurusan TKJ dididik untuk mampu melakukan instalasi jaringan komputer, baik itu jaringan komputer dalam rumah / kantor, antar kantor, antar kota, antar provinsi, bahkan antar negara. </p>
        </div>

        <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
            <h2> DESAIN DAN PRODUKSI BUSANA (DP BUSANA) </h2>
            <p> menggambar busana dan lenan rumah tangga, mengoperasikan mesin jahit. membuat pola dasar dan mengubah pola berbagai jenis busana dan lenan rumah tangga, menggunting bahan busana, dan menjahit busana dan lenan rumah tangga dengan memperhatikan kesehatan dan keselamatan kerja </p>
        </div>
    </section>
    <section id="visi-misi" class="sm:grid sm:grid-cols-2 sm:container sm:mx-auto border p-2 my-5">
        <div class="prose">
            <h2> Visi </h2>
            <p> Unggul dalam Prestasi Akademik dan Non Akademik serta menciptakan lulusan yang berkompeten sesuai kebutuhan industri berdasarkan IMTAQ </p>

            <h2> Misi </h2>
            <p> Menghasilkan Lulusan yang Cerdas , Trampil, Kompetitif dan Mandiri Sehingga Mempunyai Nilai Juang yang Tinggi.
                Meningkatkan Mutu Pembelajaran yang mencakup Ilmu Pengetahuan dan Teknologi Dengan Menjunjung Tinggi Budaya Bangsa dan Budi Pekerti yang Luhur.
                Membina HubunganYang Harmonis dan Saling Menguntungkan Antara Sekolah Dunia Industri dan Dunia Usaha.
                Menanamkan Jiwa Kewirausahaan (Enterpreneurship).
                Mengembangkan Life Skill ( Kecakapan Hidup ) Melalui Kegiatan Ekstrakulikuler, Latihan Berwirausaha dengan Sepesifik Yang Bersetandar pada Kompetensi Keahlian Kerja.
                Mengembangkan Program Keahlian yang Merupakan Tuntutan Pasar Kerja , Menanamkan Budaya Kerja dan Sikap Profersional Untuk Menunjang Hidup Layak Melalui Pengembangan Karir.
                Membentuk Sikap dan Perilaku Santun Serta Berbudi Luhur Berbasis Imtaq Dengan Menjunjung Tinggi Nilai-nilai Luhur Budaya Bangsa. </p>
        </div>
        <div>
            <iframe class="w-full h-full" src="https://www.youtube.com/embed/tgbNymZ7vqY">
            </iframe>
        </div>
    </section>
    <section id="fakta-menarik" class="prose mx-auto my-14">
        <h1 class="text-center">Fakta Menarik Tentang SMK Al-Azhar</h1>
        <div class="sm:grid sm:grid-cols-4 text-center">
            <div class="bg-red-400 text-white my-1 mx-5">
                500 Siswa
            </div>
            <div class="bg-red-400 text-white my-1 mx-5">
                5 Laboratorium
            </div>
            <div class="bg-red-400 text-white my-1 mx-5">
                57 Karyawan
            </div>
            <div class="bg-red-400 text-white my-1 mx-5">
                5 Jurusan
            </div>
        </div>
    </section>
    <section id="guru" class="mx-auto my-14">
        <div class="prose mx-auto">
            <h1 class="text-center">Guru & Karyawan</h1>
        </div>
        <div class="sm:grid md:grid-cols-2 lg:grid-cols-4">
            <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                <img src="<?php echo e(asset('image/001.jpg')); ?>" alt="guru1">
            </div>
            <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                <img src="<?php echo e(asset('image/002.jpg')); ?>" alt="guru1">
            </div>
            <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                <img src="<?php echo e(asset('image/004.jpg')); ?>" alt="guru1">
            </div>
            <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                <img src="<?php echo e(asset('image/005.jpg')); ?>" alt="guru1">
            </div>
        </div>
    </section>
</section>
<?php echo $__env->yieldContent('konten2'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('webBeranda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmerphpjavascript/Documents/website-portofolio-sekolah/web_portal_test/resources/views/webProfil.blade.php ENDPATH**/ ?>