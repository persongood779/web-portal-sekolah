<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('sukses')): ?>
<div class="alert alert-info">
    <?php echo e($message); ?>

</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert alert-danger">
    <?php echo e($item); ?>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<form action="<?php echo e(url('/home/berita')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="judul">Judul</label>
        <input type="text" name="judul" id="judul">
    </div>
    <div class="mb-3">
        <label for="link_gambar">Link Gambar</label>
        <input type="text" name="link_gambar" id="link_gambar">
    </div>
    <div class="mb-3">
        <label for="isi">Isi</label>
        <input type="text" name="isi" id="isi">
    </div>
    <button type="submit" name="simpan">Simpan</button>
</form>

<table>
    <tr>
        <th>ID</th>
        <th>Judul</th>
        <th>Link Gambar</th>
        <th>Isi</th>
        <th>Aksi</th>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->id); ?></td>
        <td><?php echo e($item->judul); ?></td>
        <td><?php echo e($item->link_gambar); ?></td>
        <td><?php echo e($item->isi); ?></td>
        <td>
            <form action="<?php echo e(url('/home/berita/'.$item->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit">
                    Hapus
                </button>
            </form>
            <form action="<?php echo e(url('/home/berita/'.$item->id."/edit")); ?>" method="get">
                <?php echo csrf_field(); ?>
                <?php echo method_field('UPDATE'); ?>
                <button type="submit">
                    Update
                </button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmerphpjavascript/Documents/website-portofolio-sekolah/web_portal_sekolah/resources/views/admin/berita_crd.blade.php ENDPATH**/ ?>