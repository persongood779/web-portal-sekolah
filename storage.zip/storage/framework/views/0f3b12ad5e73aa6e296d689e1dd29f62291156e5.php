<?php $__env->startSection('cont'); ?>
<section id="profil" class="my-10">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="prose prose-h1:mb-0 prose-p:mt-0 block mx-auto text-center prose-sm">
        <h1> Jurusan SMK Al-Azhar </h1>
        <p>Berikut adalah 5 jurusan di smk al-azhar</p>
    </div>
    <section id="jurusan" class="sm:grid sm:grid-cols-2 sm:self-center lg:grid-cols-3 lg:container lg:mx-auto">
        <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
            <h2> AKUNTANSI DAN KEAUANGAN LEMBAGA (AKL) </h2>
            <p><?php echo e($item2->akl); ?></p>
        </div>

        <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
            <h2> TEKNIK KENDARAAN RINGAN OTOMOTIF (TKRO) </h2>
            <p><?php echo e($item2->tkro); ?></p>
        </div>
        <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
            <h2> REKAYASA PERANGKAT LUNAK (RPL) </h2>
            <p><?php echo e($item2->rpl); ?></p>
        </div>

        <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
            <h2> TEKNIK KOMPUTER DAN JARINGAN (TKJ) </h2>
            <p><?php echo e($item2->tkj); ?></p>
        </div>

        <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
            <h2> DESAIN DAN PRODUKSI BUSANA (DP BUSANA) </h2>
            <p><?php echo e($item2->dpb); ?></p>
        </div>
    </section>
    <section id="visi-misi" class="sm:grid sm:grid-cols-2 sm:container sm:mx-auto border p-2 my-5">
        <div class="prose">
            <?php echo e($item2->visi_misi); ?>

        </div>
        <div>
            <iframe class="w-full h-full" src="https://www.youtube.com/embed/tgbNymZ7vqY">
            </iframe>
        </div>
    </section>
    <section id="fakta-menarik" class="prose mx-auto my-14">
        <h1 class="text-center">Fakta Menarik Tentang SMK Al-Azhar</h1>
        <div class="sm:grid sm:grid-cols-4 text-center">
            <div class="bg-red-400 text-white my-1 mx-5">
                <p><?php echo e($item2->siswa); ?></p> Siswa
            </div>
            <div class="bg-red-400 text-white my-1 mx-5">
                <p><?php echo e($item2->laboratorium); ?></p> Laboratorium
            </div>
            <div class="bg-red-400 text-white my-1 mx-5">
                <p><?php echo e($item2->karyawan); ?></p> Karyawan
            </div>
            <div class="bg-red-400 text-white my-1 mx-5">
                <p><?php echo e($item2->jurusan); ?></p> Jurusan
            </div>
        </div>
    </section>
    <section id="guru" class="mx-auto my-14">
        <div class="prose mx-auto">
            <h1 class="text-center">Guru & Karyawan</h1>
        </div>
        <div class="sm:grid md:grid-cols-2 lg:grid-cols-4">
            <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                <img src="<?php echo e(asset('image/001.jpg')); ?>" alt="guru1">
            </div>
            <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                <img src="<?php echo e(asset('image/002.jpg')); ?>" alt="guru1">
            </div>
            <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                <img src="<?php echo e(asset('image/004.jpg')); ?>" alt="guru1">
            </div>
            <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                <img src="<?php echo e(asset('image/005.jpg')); ?>" alt="guru1">
            </div>
        </div>
    </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmerphpjavascript/Documents/website-portofolio-sekolah/web_portal_test/resources/views/profil.blade.php ENDPATH**/ ?>