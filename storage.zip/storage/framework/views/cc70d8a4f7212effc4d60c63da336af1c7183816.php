<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('sukses')): ?>
<div class="alert alert-info container mx-auto" style="max-width: 18rem;">
    <?php echo e($message); ?>

</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert alert-danger container mx-auto" style="max-width: 24rem;">
    <?php echo e($item); ?>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<div class="container mx-auto text-center mb-5">
    <h1>CRUD Berita</h1>
    <button type="submit" class="btn btn-primary">
        <a href="<?php echo e(url('/home')); ?>" class="text-white" style="text-decoration: none;">ke Home</a>
    </button>
</div>
<form action="<?php echo e(url('/home/berita')); ?>" method="post" class="container mx-auto border rounded p-3" style="max-width: 36rem;">
    <?php echo csrf_field(); ?>
    <h1 class="text-center">Tambah Berita</h1>
    <div class="mb-3">
        <label for="judul" class="form-label">Judul</label>
        <input type="text" class="form-control" name="judul" id="judul">
    </div>
    <div class="mb-3">
        <label for="link_gambar" class="form-label">Link Gambar</label>
        <input type="text" class="form-control" name="link_gambar" id="link_gambar" placeholder="mohon masukkan alamat link gambar dari google atau yang sejenis...">
    </div>
    <div class="mb-3">
        <label for="isi" class="form-label">Isi</label>
        <textarea class="form-control" cols="30" rows="10" type="text" name="isi" id="isi"></textarea>
    </div>
    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
</form>

<table class="table table-primary table-stripped container mx-auto border my-5">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Judul</th>
            <th scope="col">Gambar</th>
            <th scope="col">Isi Berita</th>
            <th scope="col">Aksi 1</th>
            <th scope="col">Aksi 2</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($item->id); ?></th>
            <td><?php echo e($item->judul); ?></td>
            <td><?php echo e($item->link_gambar); ?></td>
            <td style="max-width: 24rem;"><?php echo e($item->isi); ?></td>
            <td>
                <form action="<?php echo e(url('/home/berita/'.$item->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">
                        Hapus
                    </button>
                </form>
            </td>
            <td>
                <form action="<?php echo e(url('/home/berita/'.$item->id."/edit")); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('UPDATE'); ?>
                    <button type="submit" class="btn btn-primary">
                        Update
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmerphpjavascript/Documents/website-portofolio-sekolah/web_portal_test/resources/views/admin/berita_crd.blade.php ENDPATH**/ ?>