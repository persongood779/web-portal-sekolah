<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    Web Admin Portal Sekolah
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <?php endif; ?>
                        <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <div class="container mx-auto text-center">
                <h1>UPDATE Profil</h1>
                <button type="submit" class="btn btn-primary">
                    <a href="<?php echo e(url('/home')); ?>" class="text-white" style="text-decoration: none;">ke Home</a>
                </button>
            </div>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="<?php echo e(url('/home/profil/'.$item->id)); ?>" method="post" class="container mx-auto border rounded mt-5" style="max-width: 36rem;">
                <h3 class="text-center">Update Informasi Profil</h3>
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="mb-3">
                    <label for="akl" class="form-label">Informasi AKL</label>
                    <textarea type="text" name="akl" id="akl" class="form-control" cols="30" rows="10">
                        <?php echo e($item->akl); ?>

                    </textarea>
                </div>
                <div class="mb-3">
                    <label for="tkro" class="form-label">Informasi TKRO</label>
                    <textarea type="text" name="tkro" id="tkro" class="form-control" cols="30" rows="10">
                        <?php echo e($item->tkro); ?>

                    </textarea>
                </div>
                <div class="mb-3">
                    <label for="rpl" class="form-label">Informasi RPL</label>
                    <textarea type="text" name="rpl" id="rpl" class="form-control" cols="30" rows="10">
                        <?php echo e($item->rpl); ?>

                    </textarea>
                </div>
                <div class="mb-3">
                    <label for="tkj" class="form-label">Informasi TJK</label>
                    <textarea type="text" name="tkj" id="tkj" class="form-control" cols="30" rows="10">
                        <?php echo e($item->tkj); ?>

                    </textarea>
                </div>
                <div class="mb-3">
                    <label for="dpb" class="form-label">Informasi DPB</label>
                    <textarea type="text" name="dpb" id="dpb" class="form-control" cols="30" rows="10">
                        <?php echo e($item->dpb); ?>

                    </textarea>
                </div>
                <div class="mb-3">
                    <label for="siswa" class="form-label">Jumlah Siswa</label>
                    <input type="number" name="siswa" id="siswa" class="form-control" value="<?php echo e($item->siswa); ?>">
                </div>
                <div class="mb-3">
                    <label for="laboratorium" class="form-label">Jumlah Laboratorium</label>
                    <input type="number" name="laboratorium" id="laboratorium" class="form-control" value="<?php echo e($item->laboratorium); ?>">
                </div>
                <div class="mb-3">
                    <label for="karyawan" class="form-label">Jumlah Karyawan</label>
                    <input type="number" name="karyawan" id="karyawan" class="form-control" value="<?php echo e($item->karyawan); ?>">
                </div>
                <div class="mb-3">
                    <label for="jurusan" class="form-label">Jumlah Jurusan</label>
                    <input type="number" name="jurusan" id="jurusan" class="form-control" value="<?php echo e($item->jurusan); ?>">
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </main>
    </div>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/programmerphpjavascript/Documents/website-portofolio-sekolah/web_portal_test/resources/views/admin/updateprofil.blade.php ENDPATH**/ ?>