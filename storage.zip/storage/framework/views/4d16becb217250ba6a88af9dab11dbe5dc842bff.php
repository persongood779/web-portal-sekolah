<?php $__env->startSection('contents'); ?>
   <form action="<?php echo e(url('/home/berita/'. $data->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-3">
        <label for="judul">Judul</label>
        <input type="text" name="judul" id="judul" value="<?php echo e($data->judul); ?>">
    </div>
    <div class="mb-3">
        <label for="link_gambar">Link Gambar</label>
        <input type="text" name="link_gambar" id="link_gambar" value="<?php echo e($data->link_gambar); ?>">
    </div>
    <div class="mb-3">
        <label for="isi">Isi</label>
        <input type="text" name="isi" id="isi" value="<?php echo e($data->isi); ?>">
    </div>
    <button type="submit" name="update">Update</button>
   </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/programmerphpjavascript/Documents/website-portofolio-sekolah/web_portal_sekolah/resources/views/admin/editberita.blade.php ENDPATH**/ ?>