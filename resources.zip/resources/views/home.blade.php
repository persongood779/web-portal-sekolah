@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                @if ($message = Session::get('sukses'))
                <div class="alert alert-info container mx-auto" style="max-width: 18rem;">
                    {{ $message }}
                </div>
                @endif

                @if ($errors->any())
                @foreach ($errors->all() as $item)
                <div class="alert alert-danger container mx-auto" style="max-width: 24rem;">
                    {{ $item }}
                </div>
                @endforeach
                @endif
                <div class="card-header">{{ __('Dashboard') }}</div>

                <div class="card-body p-3 text-center">
                    <button type="submit" class="btn btn-primary">
                        <a href="{{ url('/home/berita') }}" class="text-white" style="text-decoration: none;">CRUD Berita</a>
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <a href="{{ url('/home/profil') }}" class="text-white" style="text-decoration: none;">UPDATE Profil</a>
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <a href="{{ url('/home/beranda') }}" class="text-white" style="text-decoration: none;">UPDATE Beranda</a>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
