@extends('layouts.app')
@section('content')

@if ($message = Session::get('sukses'))
<div class="alert alert-info container mx-auto" style="max-width: 18rem;">
    {{ $message }}
</div>
@endif

@if ($errors->any())
@foreach ($errors->all() as $item)
<div class="alert alert-danger container mx-auto" style="max-width: 24rem;">
    {{ $item }}
</div>
@endforeach
@endif

<div class="container mx-auto text-center mb-5">
    <h1>CRUD Berita</h1>
    <button type="submit" class="btn btn-primary">
        <a href="{{ url('/home') }}" class="text-white" style="text-decoration: none;">ke Home</a>
    </button>
</div>
<form action="{{ url('/home/berita') }}" method="post" class="container mx-auto border rounded p-3" style="max-width: 36rem;">
    @csrf
    <h1 class="text-center">Tambah Berita</h1>
    <div class="mb-3">
        <label for="judul" class="form-label">Judul</label>
        <input type="text" class="form-control" name="judul" id="judul">
    </div>
    <div class="mb-3">
        <label for="link_gambar" class="form-label">Link Gambar</label>
        <input type="text" class="form-control" name="link_gambar" id="link_gambar" placeholder="mohon masukkan alamat link gambar dari google atau yang sejenis...">
    </div>
    <div class="mb-3">
        <label for="isi" class="form-label">Isi</label>
        <textarea class="form-control" cols="30" rows="10" type="text" name="isi" id="isi"></textarea>
    </div>
    <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
</form>

<table class="table table-primary table-stripped container mx-auto border my-5">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Judul</th>
            <th scope="col">Gambar</th>
            <th scope="col">Isi Berita</th>
            <th scope="col">Aksi 1</th>
            <th scope="col">Aksi 2</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($data as $item)
        <tr>
            <th scope="row">{{ $item->id }}</th>
            <td>{{ $item->judul }}</td>
            <td>{{ $item->link_gambar }}</td>
            <td style="max-width: 24rem;">{{ $item->isi }}</td>
            <td>
                <form action="{{ url('/home/berita/'.$item->id) }}" method="post">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">
                        Hapus
                    </button>
                </form>
            </td>
            <td>
                <form action="{{ url('/home/berita/'.$item->id."/edit") }}" method="get">
                    @csrf
                    @method('UPDATE')
                    <button type="submit" class="btn btn-primary">
                        Update
                    </button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection
