<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    @vite(['resources/sass/app.scss', 'resources/js/app.js'])
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    Web Admin Portal Sekolah
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        @guest
                        @if (Route::has('login'))
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                        </li>
                        @endif
                        @else
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                {{ Auth::user()->name }}
                            </a>

                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    {{ __('Logout') }}
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>
                            </div>
                        </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <div class="container mx-auto text-center">
                <h1>UPDATE Profil</h1>
                <button type="submit" class="btn btn-primary">
                    <a href="{{ url('/home') }}" class="text-white" style="text-decoration: none;">ke Home</a>
                </button>
            </div>

            @foreach ($data as $item)
            <form action="{{ url('/home/profil/'.$item->id) }}" method="post" class="container mx-auto border rounded mt-5" style="max-width: 36rem;">
                <h3 class="text-center">Update Informasi Profil</h3>
                @csrf
                @method('put')
                <div class="mb-3">
                    <label for="akl" class="form-label">Informasi AKL</label>
                    <textarea type="text" name="akl" id="akl" class="form-control" cols="30" rows="10">
                        {{ $item->akl }}
                    </textarea>
                </div>
                <div class="mb-3">
                    <label for="tkro" class="form-label">Informasi TKRO</label>
                    <textarea type="text" name="tkro" id="tkro" class="form-control" cols="30" rows="10">
                        {{ $item->tkro }}
                    </textarea>
                </div>
                <div class="mb-3">
                    <label for="rpl" class="form-label">Informasi RPL</label>
                    <textarea type="text" name="rpl" id="rpl" class="form-control" cols="30" rows="10">
                        {{ $item->rpl }}
                    </textarea>
                </div>
                <div class="mb-3">
                    <label for="tkj" class="form-label">Informasi TJK</label>
                    <textarea type="text" name="tkj" id="tkj" class="form-control" cols="30" rows="10">
                        {{ $item->tkj }}
                    </textarea>
                </div>
                <div class="mb-3">
                    <label for="dpb" class="form-label">Informasi DPB</label>
                    <textarea type="text" name="dpb" id="dpb" class="form-control" cols="30" rows="10">
                        {{ $item->dpb }}
                    </textarea>
                </div>
                <div class="mb-3">
                    <label for="siswa" class="form-label">Jumlah Siswa</label>
                    <input type="number" name="siswa" id="siswa" class="form-control" value="{{ $item->siswa }}">
                </div>
                <div class="mb-3">
                    <label for="laboratorium" class="form-label">Jumlah Laboratorium</label>
                    <input type="number" name="laboratorium" id="laboratorium" class="form-control" value="{{ $item->laboratorium }}">
                </div>
                <div class="mb-3">
                    <label for="karyawan" class="form-label">Jumlah Karyawan</label>
                    <input type="number" name="karyawan" id="karyawan" class="form-control" value="{{ $item->karyawan }}">
                </div>
                <div class="mb-3">
                    <label for="jurusan" class="form-label">Jumlah Jurusan</label>
                    <input type="number" name="jurusan" id="jurusan" class="form-control" value="{{ $item->jurusan }}">
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
            @endforeach
        </main>
    </div>
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
</body>
</html>
