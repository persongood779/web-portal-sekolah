<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Web-Sekolah</title>
    <link rel="shortcut icon" href="{{ asset('image/logo.jpeg') }}" type="image/x-icon">
    @vite(['resources/css/app.css','resources/js/app.js'])
</head>
<body>

    <section id="nav">

        <nav class="border-gray-200 px-2 sm:px-4 py-2.5 bg-blue-400 dark:bg-gray-900">
            <div class="container flex flex-wrap items-center justify-between mx-auto">
                <a href="https://flowbite.com/" class="flex items-center">
                    <span class="self-center text-xl font-semibold whitespace-nowrap dark:text-white">SMK AL-AZHAR SEMPU</span>
                </a>
                <button data-collapse-toggle="navbar-default" type="button" class="inline-flex items-center p-2 ml-3 text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-default" aria-expanded="false">
                    <span class="sr-only">Open main menu</span>
                    <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"></path>
                    </svg>
                </button>
                <div class="hidden w-full md:block md:w-auto" id="navbar-default">
                    <ul class="flex flex-col p-4 mt-4 border border-gray-100 rounded-lg bg-gray-50 md:flex-row md:space-x-8 md:mt-0 md:text-sm md:font-medium md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
                        <li>
                            <a href="{{ url('/') }}" class="block py-2 pl-3 pr-4 text-white bg-blue-700 rounded md:bg-transparent md:text-blue-700 md:p-0 dark:text-white" aria-current="page">Beranda</a>
                        </li>
                        <li>
                            <a href="{{ url('/profil') }}" class="block py-2 pl-3 pr-4 text-gray-700 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Profil</a>
                        </li>
                        <li>
                            <a href="{{ url('/berita') }}" class="block py-2 pl-3 pr-4 text-gray-700 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Berita</a>
                        </li>
                        <li>
                            <a href="#footer" class="block py-2 pl-3 pr-4 text-gray-700 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Footer</a>
                        </li>
                        <li>
                            <a href="/home" class="block py-2 pl-3 pr-4 text-gray-700 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-gray-400 md:dark:hover:text-white dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Masuk Admin</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

    </section>

    <section id="beranda">

        @foreach ($data1 as $item1)
        <div id="default-carousel" class="relative" data-carousel="static">
            <!-- Carousel wrapper -->
            <div class="relative h-56 overflow-hidden md:h-96">
                <!-- Item 1 -->
                <div class="hidden duration-700 ease-in-out" data-carousel-item>
                    <span class="absolute text-2xl font-semibold text-white -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2 sm:text-3xl dark:text-gray-800">First Slide</span>
                    <img src="{{ asset('image/bg-1.jpg') }}" class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="...">
                    <p class="absolute left-10 top-10 font-extrabold text-xl text-green-400">
                        {{ $item1->nama_sekolah }}
                    </p>
                </div>
                <!-- Item 2 -->
                <div class="hidden duration-700 ease-in-out" data-carousel-item>
                    <img src="{{ asset('image/bg-2.jpg') }}" class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="...">
                    <p class="absolute left-10 top-10 font-extrabold text-xl text-teal-300">
                        TER <span class="text-black"> AKREDITASI </span> {{ $item1->akreditasi }}
                    </p>
                </div>
                <!-- Item 3 -->
                <div class="hidden duration-700 ease-in-out" data-carousel-item>
                    <img src="{{ asset('image/bg-3.jpg') }}" class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2" alt="...">
                    <p class="absolute left-10 top-10 font-extrabold text-white text-xl">
                        MEMILIKI <span class="text-yellow-400"> {{ $item1->jurusans }} JURUSAN </span>
                    </p>
                </div>
            </div>
            <!-- Slider indicators -->
            <div class="absolute z-30 flex space-x-3 -translate-x-1/2 bottom-5 left-1/2">
                <button type="button" class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 1" data-carousel-slide-to="0"></button>
                <button type="button" class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 2" data-carousel-slide-to="1"></button>
                <button type="button" class="w-3 h-3 rounded-full" aria-current="false" aria-label="Slide 3" data-carousel-slide-to="2"></button>
            </div>
            <!-- Slider controls -->
            <button type="button" class="absolute top-0 left-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none" data-carousel-prev>
                <span class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-white/30 dark:bg-gray-800/30 group-hover:bg-white/50 dark:group-hover:bg-gray-800/60 group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                    <svg aria-hidden="true" class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                    </svg>
                    <span class="sr-only">Previous</span>
                </span>
            </button>
            <button type="button" class="absolute top-0 right-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none" data-carousel-next>
                <span class="inline-flex items-center justify-center w-8 h-8 rounded-full sm:w-10 sm:h-10 bg-white/30 dark:bg-gray-800/30 group-hover:bg-white/50 dark:group-hover:bg-gray-800/60 group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none">
                    <svg aria-hidden="true" class="w-5 h-5 text-white sm:w-6 sm:h-6 dark:text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                    <span class="sr-only">Next</span>
                </span>
            </button>
        </div>
        @endforeach
    </section>
    <div class="text-center bg-slate-400 py-3">
        <button type="submit" class="p-2 border rounded bg-blue-400 mx-2"><a href="{{ url('/') }}">Beranda</a></button>
        <button type="submit" class="p-2 border rounded bg-blue-400 mx-2"><a href="{{ url('/profil') }}">Profil</a></button>
        <button type="submit" class="p-2 border rounded bg-blue-400 mx-2"><a href="{{ url('/berita') }}">Berita</a></button>

    </div>

    <section id="profil" class="my-10">
        @foreach ($data2 as $item2)

        <div class="prose prose-h1:mb-0 prose-p:mt-0 block mx-auto text-center prose-sm">
            <h1> Jurusan SMK Al-Azhar </h1>
            <p>Berikut adalah 5 jurusan di smk al-azhar</p>
        </div>
        <section id="jurusan" class="sm:grid sm:grid-cols-2 sm:self-center lg:grid-cols-3 lg:container lg:mx-auto">
            <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
                <h2> AKUNTANSI DAN KEAUANGAN LEMBAGA (AKL) </h2>
                <p>{{ $item2->akl }}</p>
            </div>

            <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
                <h2> TEKNIK KENDARAAN RINGAN OTOMOTIF (TKRO) </h2>
                <p>{{ $item2->tkro }}</p>
            </div>
            <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
                <h2> REKAYASA PERANGKAT LUNAK (RPL) </h2>
                <p>{{ $item2->rpl }}</p>
            </div>

            <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
                <h2> TEKNIK KOMPUTER DAN JARINGAN (TKJ) </h2>
                <p>{{ $item2->tkj }}</p>
            </div>

            <div class="prose xl:my-4 max-w-lg sm:max-w-sm p-6 bg-white border border-gray-200 shadow dark:bg-gray-800 dark:border-gray-700">
                <h2> DESAIN DAN PRODUKSI BUSANA (DP BUSANA) </h2>
                <p>{{ $item2->dpb }}</p>
            </div>
        </section>
        <section id="visi-misi" class="sm:grid sm:grid-cols-2 sm:container sm:mx-auto border p-2 my-5">
            <div class="prose">
                {{ $item2->visi_misi }}
            </div>
            <div>
                <iframe class="w-full h-full" src="https://www.youtube.com/embed/tgbNymZ7vqY">
                </iframe>
            </div>
        </section>
        <section id="fakta-menarik" class="prose mx-auto my-14">
            <h1 class="text-center">Fakta Menarik Tentang SMK Al-Azhar</h1>
            <div class="sm:grid sm:grid-cols-4 text-center">
                <div class="bg-red-400 text-white my-1 mx-5">
                    <p>{{ $item2->siswa }}</p> Siswa
                </div>
                <div class="bg-red-400 text-white my-1 mx-5">
                    <p>{{ $item2->laboratorium }}</p> Laboratorium
                </div>
                <div class="bg-red-400 text-white my-1 mx-5">
                    <p>{{ $item2->karyawan }}</p> Karyawan
                </div>
                <div class="bg-red-400 text-white my-1 mx-5">
                    <p>{{ $item2->jurusan }}</p> Jurusan
                </div>
            </div>
        </section>
        <section id="guru" class="mx-auto my-14">
            <div class="prose mx-auto">
                <h1 class="text-center">Guru & Karyawan</h1>
            </div>
            <div class="sm:grid md:grid-cols-2 lg:grid-cols-4">
                <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                    <img src="{{ asset('image/001.jpg') }}" alt="guru1">
                </div>
                <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                    <img src="{{ asset('image/002.jpg') }}" alt="guru1">
                </div>
                <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                    <img src="{{ asset('image/004.jpg') }}" alt="guru1">
                </div>
                <div class="p-6 bg-white rounded-lg shadow dark:bg-gray-800">
                    <img src="{{ asset('image/005.jpg') }}" alt="guru1">
                </div>
            </div>
        </section>
        @endforeach
    </section>

    <div class="prose text-center my-2 bg-red-200">
        <h1>Berita SMK</h1>
    </div>
    <section id="berita" class="sm:grid sm:grid-cols-2">
        @foreach ($data3 as $item3)
        <div class="p-2 prose container mx-auto">
            <h1>{{ $item3->judul }}</h1>
            <img src="{{ $item3->link_gambar }}" alt="" class="w-full">
            <p class="line-clamp-6 hover:line-clamp-none">
                {{ $item3->isi }}
            </p>
        </div>
        @endforeach
    </section>

    <section id="footer" class="bg-black text-white text-center">
        @copyrigth 31-1-2023 muhamad abdul ghofur
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.6.3/flowbite.min.js"></script>
</body>
</html>
