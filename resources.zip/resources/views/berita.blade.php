@extends('portal')
@section('cont')
<h1 class="text-center text-4xl mb-5">Berita</h1>
<section id="berita" class="sm:grid sm:grid-cols-2">
    @foreach ($data as $item3)
    <div class="p-2 prose container mx-auto">
        <h1>{{ $item3->judul }}</h1>
        <img src="{{ $item3->link_gambar }}" alt="" class="w-full">
        <p class="line-clamp-6 hover:line-clamp-none">
            {{ $item3->isi }}
        </p>
    </div>
    @endforeach
</section>
]@endsection
