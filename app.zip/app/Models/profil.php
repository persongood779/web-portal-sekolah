<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class profil extends Model
{
    use HasFactory;
    protected $fillable = ['akl', 'tkro', 'rpl', 'tkj', 'dpb', 'visi-misi', 'siswa', 'laboratorium', 'karyawan', 'jurusan'];
    protected $table = 'profil';
}
