<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class beranda extends Model
{
    use HasFactory;
    protected $fillable = ['nama_sekolah', 'akreditasi', 'jurusans'];
    protected $table = 'beranda';
}
