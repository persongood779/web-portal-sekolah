<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\beranda;
use App\Models\berita;
use App\Models\profil;

class webController extends Controller
{
    function index() {
        $data1 = beranda::orderBy('id', 'desc')->get();
        $data2 = profil::orderBy('id', 'desc')->get();
        $data3 = berita::orderBy('id', 'desc')->get();
        return view('portal', compact('data1', 'data2', 'data3'));
    }
}
