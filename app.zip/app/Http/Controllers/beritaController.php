<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\berita;

class beritaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = berita::orderBy('id', 'desc')->get();
        return view('admin.berita_crd')->with('data', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.berita_crd');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'judul'=>'required',
            'link_gambar'=>'required',
            'isi'=>'required',
        ]);
        berita::create($request->all());
        return redirect('/home/berita')->with('sukses', 'sukses menambahkan data');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $datas = berita::where('id', $id)->first();
        return view('admin.edit_berita')->with('datas', $datas);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = [
            'judul'=>$request->judul,
            'link_gambar'=>$request->link_gambar,
            'isi'=>$request->isi,
        ];
        berita::where('id', $id)->update($data);
        return redirect('/home/berita')->with('sukses', 'sukses mengubah data');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        berita::where('id', $id)->delete();
        return redirect('/home/berita')->with('sukses', 'sukses menghapus data');
    }
}
